import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import HomePage from './containers/HomePage';
import Services from './containers/Services';
import Navbar from './components/Navbar';
import VideoBackground from './components/VideoBackground';
function App() {
  return (

    <Router>
      <VideoBackground/>
      <Navbar/>
      <Routes>
      
        <Route path="/"  element={<HomePage />} />
        <Route path="/services" element={<Services />} />
      </Routes>
    </Router>
  );
}

export default App;
