import React from 'react';
import './HomePage.css';
import ServiceDetails from '../components/ServiceDetails';
import HoverButton from '../components/HoverButton';
import MapComponent from '../components/MapComponent';
function Home() {
  const servicesData = [
    {
      servImg: 'https://static.wixstatic.com/media/11062b_a792f2aac2a348cba548294b8bad64f2~mv2.jpg/v1/crop/x_1112,y_0,w_2776,h_3333/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Paint%20Roll.jpg',
      servName: 'Paint',
      servDesc: 'Transform your space with our professional and reliable home painting service using top-quality paint and materials.',
    },
    {
      servImg: 'https://static.wixstatic.com/media/11062b_41d1a2b14e514567a9b988f602347352~mv2.jpg/v1/crop/x_1160,y_0,w_2896,h_3477/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Construction%20Work.jpg',
      servName: 'Construction',
      servDesc: 'Our construction service delivers professional and reliable building solutions with a team of experienced contractors and skilled trades people.'
    },
    {
        servImg: 'https://static.wixstatic.com/media/c3c5681bc715ca4b437853634564ce00.jpg/v1/crop/x_334,y_0,w_833,h_1000/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Building%20Under%20Construction%204.jpg',
        servName: 'Maintainence',
        servDesc: 'Keep your property in top condition with our comprehensive service,offering promt and efficient solutions.'
    },
    {
        servImg: 'https://static.wixstatic.com/media/11062b_8c02d89561c44425a7b3bd67bd9f2135~mv2.jpg/v1/crop/x_1110,y_0,w_2780,h_3338/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Renovated%20Space.jpg',
        servName: 'Renovation',
        servDesc: 'Revamp your space with our expert renovation service, delivering high-quality workmanship and personalized solutions.'
    },
  ];
  const projectsData = [{
    projImg: 'https://dailycivil.com/wp-content/uploads/2018/06/5184.webp'
  }];
  return (
    <div>
      <div className='guarantee'>
      <h1>Top Quality Guaranteed</h1>
        <p>
        Looking for a licensed and experienced professional to tackle a project?
        Get guaranteed quality results with Housingcircle.com.
        We offer professional and reliable services for a wide variety of needs,
        working with the dedication and craftsmanship that has earned us a reputation for excellence.
        </p>
        <text>Get in touch today.</text>
        <br/>
        <HoverButton text={'Get in Touch'} textColor={'green'} bgColor={'white'}/>
      </div>
      <div className='services'>
            <text>SERVICES</text>
            <br/>
            {servicesData.map((service, index) => (
        <ServiceDetails key={index} {...service} />
      ))}
      </div>
      <section id="about">
        <div className='about-content'>
        <h1>ABOUT</h1>
      <br/>
        <p>
        We are a team of professionals offering a range of services to enhance 
        and maintain your home or commercial property. 
        Our services include home painting, maintenance, and construction. 
        Our team of experienced painters use high-quality materials and techniques 
        to provide a smooth and long-lasting finish to any interior or exterior surface. 
        Our maintenance services range from simple repairs to full renovations, ensuring 
        your property is well-maintained and in top condition. 
        Our construction services cover a wide range of projects, from small additions to 
        full-scale renovations.
        Contact us today to discuss your needs and schedule a free consultation and estimate 
        for your next project.
        </p>
        <text>Get in touch today.</text>
        </div>
      
      </section>
      <div className='info'>
             <div className='info-details'><text>2022</text>
                  <text className='info-text'>Year Established</text>
             </div><div className='line'></div>
             <div className='info-details'><text>2022</text>
                  <text className='info-text'>Year Established</text>
             </div><div className='line'></div>
             <div className='info-details'><text>2022</text>
                  <text className='info-text'>Year Established</text>
             </div><div className='line'></div>
             <div className='info-details'><text>2022</text>
                  <text className='info-text'>Year Established</text>
             </div><div className='line'></div>
        </div>
      <section id="projects">
        <h2>Projects</h2>
        <div className='projects-img'>
        {/* {projectsData.map((projImg, index) => (
        <img key={index} src={projImg} alt='' height={'455px'} width={'455px'}/>
      ))} */}
      <img src='https://i0.wp.com/theconstructor.org/wp-content/uploads/2022/11/Simple-Flyovers.png?resize=380%2C380&ssl=1' alt='' height={'455px'} width={'455px'}/>
      <img src='https://images.livemint.com/img/2022/08/22/600x338/Construction_workers_1661185829613_1661185829786_1661185829786.JPG' alt='' height={'455px'} width={'455px'}/>
      <img src='https://upload.wikimedia.org/wikipedia/commons/0/0c/GoldenGateBridge-001.jpg' alt='' height={'455px'} width={'455px'}/>
      <img src='https://acropolis-wp-content-uploads.s3.us-west-1.amazonaws.com/Building-Types-Hero.webp' alt='' height={'455px'} width={'455px'}/>
        </div>
      </section>

      <section id="contact">
        <h2>Contact</h2>
        {/* <MapComponent/> */}
        <div class="contact-form">
        
        <div class="form-group">
            

        <div class="form-group">
            <form action="#" method="post">
                <div class="form-group">
                    <label for="firstName">First Name</label>
                    <input type="text" id="firstName" name="firstName" required/>
                </div>

                <div class="form-group">
                    <label for="lastName">Last Name</label>
                    <input type="text" id="lastName" name="lastName" required/>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required/>
                </div>

                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" required/>
                </div>

                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" rows="4" required></textarea>
                </div>

                <button type="submit">Submit</button>
            </form>
            </div>
        </div>
    </div>
<div>
<label for="inquiries">Inquiries</label>
            <p>For any inquiries, questions or commendations, please call: +91-835-705-4262 or fill out the following form</p>
            <label for="employment">Employment</label>
            <p>To apply for a job with Housing-Circle, please send a cover letter together with your C.V. to: housingcircle2022@gmail.com</p>
        </div>
      </section>
    </div>
  );
}

export default Home;
