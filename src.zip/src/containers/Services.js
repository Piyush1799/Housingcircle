import React from 'react';
import ServiceDetails from '../components/ServiceDetails';
import './Services.css';
function Services() {
  const servicesData = [
    {
      servImg: 'https://static.wixstatic.com/media/11062b_a792f2aac2a348cba548294b8bad64f2~mv2.jpg/v1/crop/x_1112,y_0,w_2776,h_3333/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Paint%20Roll.jpg',
      servName: 'Paint',
      servDesc: 'Transform your space with our professional and reliable home painting service using top-quality paint and materials.',
    },
    {
      servImg: 'https://static.wixstatic.com/media/11062b_41d1a2b14e514567a9b988f602347352~mv2.jpg/v1/crop/x_1160,y_0,w_2896,h_3477/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Construction%20Work.jpg',
      servName: 'Construction',
      servDesc: 'Our construction service delivers professional and reliable building solutions with a team of experienced contractors and skilled trades people.'
    },
    {
        servImg: 'https://static.wixstatic.com/media/c3c5681bc715ca4b437853634564ce00.jpg/v1/crop/x_334,y_0,w_833,h_1000/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Building%20Under%20Construction%204.jpg',
        servName: 'Maintainence',
        servDesc: 'Keep your property in top condition with our comprehensive service,offering promt and efficient solutions.'
    },
    {
        servImg: 'https://static.wixstatic.com/media/11062b_8c02d89561c44425a7b3bd67bd9f2135~mv2.jpg/v1/crop/x_1110,y_0,w_2780,h_3338/fill/w_269,h_323,al_c,q_80,usm_0.66_1.00_0.01,enc_auto/Renovated%20Space.jpg',
        servName: 'Renovation',
        servDesc: 'Revamp your space with our expert renovation service, delivering high-quality workmanship and personalized solutions.'
    },
  ];
const backgroundImage = 'https://static.wixstatic.com/media/11062b_bda1af837ca04e5d9b3975f90a70edbf~mv2.jpeg/v1/fill/w_1269,h_374,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/11062b_bda1af837ca04e5d9b3975f90a70edbf~mv2.jpeg'
  return (
    <>
    <div style={{ backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', minHeight: '600px' }}>
      <text>Services</text>
      <p>Explore our comprehensive range of home services.</p>

      {servicesData.map((service, index) => (
        <ServiceDetails key={index} {...service} />
      ))}
    </div>
    <div className='contact-form'>
        <h3>Contact us today to discuss your needs.</h3>
        <form>
          <label>
            First Name:
            <input type="text" name="firstName" />
          </label>
          <br />
          <label>
            Last Name:
            <input type="text" name="lastName" />
          </label>
          <br />
          <label>
            Number:
            <input type="text" name="phoneNumber" />
          </label>
          <br />
          <button type="submit">Send</button>
        </form>
      </div>
    </>
  );
}

export default Services;
