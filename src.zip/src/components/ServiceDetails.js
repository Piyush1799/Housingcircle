import React from 'react';

function ServiceDetails({ servImg, servName, servDesc }) {
  return (
    <div style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)', padding: '20px', margin: '20px 0', borderRadius: '8px' }}>
      <img src={servImg} alt={servName} style={{ maxWidth: '100%', height: 'auto', borderRadius: '8px' }} />
      <h3>{servName}</h3>
      <p>{servDesc}</p>
    </div>
  );
}

export default ServiceDetails;
