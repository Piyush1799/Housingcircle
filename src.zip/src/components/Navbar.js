import React from "react";
import { Link } from 'react-router-dom';
import '../components/Navbar.css';
const Navbar = ()=>{
    return(
        <>
        <div className="nav">
          <div className="logo">
              <img src="https://static.wixstatic.com/media/2ab964_daf9e686e8b7457b8fd89aba8a064db6~mv2.png/v1/fill/w_76,h_70,al_c,q_85,usm_0.66_1.00_0.01,enc_auto/Screenshot%20(293)_edited.png" alt="logo" height={60} width={60}/>
                <a housing-link>
                    Housingcircle
                </a>
          </div>
          <div className="nav-links">
          <div className="link">
          <Link to="/">Home</Link>
          </div>
          <div className="link">
          <Link to="/services">Services</Link>
          </div>
          <div className="link">
            <a href="#about">
                ABOUT
            </a>
          </div>
          <div className="link">
            <a href="#Projects">
                PROJECTS
            </a>
          </div>
          <div className="link">
            <a href="#contact">
                CONTACT
            </a>
          </div>
          </div>
        </div>
        </>
    );
}

export default Navbar;