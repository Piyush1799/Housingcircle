import React from 'react';
import Navbar from './Navbar';
import Button from './Button'

const Home = () =>{
    return(
    <>
    <Navbar/>
    <div id='guarantee'>
        <h1>Top Quality Guaranteed</h1>
        <p>
        Looking for a licensed and experienced professional to tackle a project? Get guaranteed quality results with Housingcircle.com. We offer professional and reliable services for a wide variety of needs, working with the dedication and craftsmanship that has earned us a reputation for excellence.
        </p>
        <text>Get in touch today.</text>
        <Button/>
    </div>
    </>
    );
}

export default Home;