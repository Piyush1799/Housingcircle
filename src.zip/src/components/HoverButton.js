import React, { useState } from 'react';

const HoverButton = ({ text, textColor, bgColor }) => {
  const [isHovered, setIsHovered] = useState(false);

  const handleHover = () => {
    setIsHovered(!isHovered);
  };

  const getButtonStyle = () => {
    if (isHovered) {
      return {
        color: bgColor,
        backgroundColor: textColor,
        height: 'max-content',
        width: 'max-content',
        font: '30px Arial, sans-serif',
        marginTop: '40px',
        transition: 'color 0.3s ease',
      };
    }

    return {
      color: textColor,
      backgroundColor: bgColor,
      height: 'max-content',
      width: 'max-content',
      font: '30px Arial, sans-serif',
      marginTop: '40px',
    };
  };

  return (
    <button
      style={getButtonStyle()}
      onMouseEnter={handleHover}
      onMouseLeave={handleHover}
    >
      {text}
    </button>
  );
};

export default HoverButton;
