import React, { useEffect } from 'react';
import mapboxgl from 'mapbox-gl';

const MapComponent = () => {
  useEffect(() => {
    // Replace 'YOUR_MAPBOX_ACCESS_TOKEN' with your actual Mapbox access token
    mapboxgl.accessToken = 'pk.eyJ1IjoicHMxNzk5IiwiYSI6ImNscjF5aXd3aTB3c3YyaW52aWlienR5ZnUifQ.ppouSokDnrPAVjlT-zew3Q';

    const map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/mapbox/streets-v11',
      center: [78.157363, 26.203725], // Gwalior coordinates
      zoom: 12,
    });

    // Add markers for each feature
    const features = [
      { coordinates: [78.203725, 26.203725], name: 'Gwalior' },
      { coordinates: [78.169144, 26.226316], name: 'Gwalior Fort' },
      { coordinates: [78.186961, 26.145585], name: 'Sitholi Railway Station' },
      { coordinates: [78.182636, 26.216025], name: 'Gwalior Junction' },
      { coordinates: [78.185057, 26.216179], name: 'Park Inn by Radisson' },
    ];

    features.forEach((feature) => {
      const marker = new mapboxgl.Marker()
        .setLngLat(feature.coordinates)
        .setPopup(new mapboxgl.Popup().setHTML(`<p>${feature.name}</p>`))
        .addTo(map);
    });

    return () => {
      map.remove();
    };
  }, []);

  return <div id="map" style={{ width: '100%', height: '400px' }}></div>;
};

export default MapComponent;
