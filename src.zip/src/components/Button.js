import React from "react";
import './Button.css'
const Button = () =>{
    <div className="button">
     <text>Get In Touch</text>
    </div>
}
export default Button;